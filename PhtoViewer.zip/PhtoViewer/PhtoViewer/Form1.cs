﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace PhtoViewer
{
    public partial class Form1 : Form
    {
        string curDir = "";
        Image img;
        public Form1()
        {
            InitializeComponent();
            pictureBox2.MinimumSize = new Size(400,400);
        }
        private void btnBrowse_Click_1(object sender, EventArgs e)
        {
            try
            { 
                var fb = new FolderBrowserDialog();
                if(fb.ShowDialog()==DialogResult.OK)
                {
                    curDir = fb.SelectedPath;
                    var DirInfo = new DirectoryInfo(curDir);
                    var files = DirInfo.GetFiles().Where(c => (c.Extension.Equals(".jpg") || c.Extension.Equals(".jpeg") || c.Extension.Equals(".bmp") || c.Extension.Equals(".png")));
                    foreach (var image in files)
                    {
                        listBox1.Items.Add(image.Name);                     
                    }
                    pictureBox2.Image = Image.FromFile(Path.Combine(curDir,Convert.ToString(listBox1.Items[0])));
                    pictureBox2.MinimumSize = new Size(pictureBox2.Image.Width,pictureBox2.Image.Height);
                }
            }
            catch (Exception) { }

        }
        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            
            
            try
            {
                var selectedImage = listBox1.SelectedItems[0].ToString();
                if (!string.IsNullOrEmpty(selectedImage) && !string.IsNullOrEmpty(curDir))
                {
                    var fullPath = Path.Combine(curDir, selectedImage);
                    pictureBox2.Image = Image.FromFile(fullPath);          
                }
            }
            catch (Exception) { }

        }
        private void btnClear_Click_1(object sender, EventArgs e)
        {
            pictureBox2.Image = null;
        }     
        private void btnLeft_Click(object sender, EventArgs e)
        {
            pictureBox2.Image.RotateFlip(RotateFlipType.Rotate90FlipXY);
            pictureBox2.Image = pictureBox2.Image;
        }
        private void btnRight_Click(object sender, EventArgs e)
        {   
            pictureBox2.Image.RotateFlip(RotateFlipType.Rotate270FlipXY);
            pictureBox2.Image = pictureBox2.Image;
        }
        private void btnZoomOut_Click(object sender, EventArgs e)
        {
            if (pictureBox2.Width > 850 && pictureBox2.Height > 400)
            {
                pictureBox2.Height -= 50;
                pictureBox2.Width -= 50;
            }
            else MessageBox.Show("zoomOut can't done ","size");
        }
        private void btnZoomIn_Click(object sender, EventArgs e)
        {        


                pictureBox2.Height += 50;
                pictureBox2.Width += 50;   
        }
    }
}
